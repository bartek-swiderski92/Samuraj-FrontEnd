$(".burger").on("click", function () {
    $(".fas, aside").toggleClass("show");
})


// const burger = document.querySelector(".burger");

// const iconBurger = document.querySelector(".fa-bars");
// const iconX = document.querySelector(".fa-times");
// const column = document.querySelector("aside");

// burger.addEventListener("click", function () {
//     iconBurger.classList.toggle("show");//tak
//     iconX.classList.toggle("show");//nie
//     column.classList.toggle("show");//nie

// })