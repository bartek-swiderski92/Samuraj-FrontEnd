console.log("ok w zenętrznym plik");
