let hello = 'w"i"taj!'
// wyświetl w konsoli
console.log(hello);
/* 
komentarz wieloliniowy
*/

var courseName = 'kurs "JS" na stronie';  //string czyli ciąg tekstowy
console.log(typeof courseName);
var numberOfPeople = 1200; //number 
console.log(typeof numberOfPeople);
var distance = 2.1432432423; //number
var female = false;  //boolean - prawda/fałsz
console.log(female, typeof female)

var onlyDeclared;  //undefined
var activeTask = null; // null
console.log(typeof onlyDeclared);
console.log(typeof activeTask);


var taskArray = [activeTask, 200, "bartek"]; //tablica
var myNewFunction = function () {
}; //funkcja
var myObj = {}; //objekt

console.log(taskArray);
// sparawdźmy typeof w konsoli